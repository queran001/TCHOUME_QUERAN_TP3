# WeatherWidget - WPF-based client application that uses OpenWeatherMap API

![alt text](https://github.com/kerminator-dev/WeatherWidget/blob/main/img/MainWindow.PNG?raw=true)
![alt text](https://github.com/kerminator-dev/WeatherWidget/blob/main/img/SettingsWindow.PNG?raw=true)

## Abstract schema

![alt text](https://github.com/kerminator-dev/WeatherWidget/blob/main/img/abstract_schema.PNG?raw=true)