﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using WeatherWidget.Helpers.JSON;

namespace WeatherWidget.Helpers
{
    
    public class OpenWeatherManager
    {
        
        private string _city;

        
        public string City
        {
            get => _city;
            private set
            {
                _city = value;

                
                _url = $"http://api.openweathermap.org/data/2.5/forecast?q={value}&lang=en-us&units=metric&appid={_apiKey}";
            }
        }

        
        private string _url;

        
        private string _apiKey { get; set; }

        
        public OpenWeatherManager(string apiKey)
        {
            _apiKey = apiKey;
        }

       
        public OpenWeatherResponce? GetWeatherData(string city)
        {
            this.City = city;
            return Converters.JsonConverter.ToOpenWeatherResponce(this.GetJSONResponce());
        }

       
        private JSONResponce? GetJSONResponce()
        {
            try
            {
                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(_url);
                HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                string responce = String.Empty;

                using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
                {
                    responce = streamReader.ReadToEnd();
                }

                httpWebResponse.Close();

                return JsonConvert.DeserializeObject<JSONResponce>(responce);
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static bool IsValidURL(string URL)
        {
            try
            {
                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(URL);
                HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                httpWebResponse.Close();
            }
            catch
            {
                return false;
            }
            return true;
        }
    }
}
