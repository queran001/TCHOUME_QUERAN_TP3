﻿using System.Windows.Controls;

namespace WeatherWidget.Views
{
    public partial class DayItemControl : UserControl
    {
        public DayItemControl()
        {
            InitializeComponent();
        }
    }
}
