﻿using System.Windows;
using System.Windows.Input;
using WeatherWidget.ViewModels;

namespace WeatherWidget.Views
{
    public partial class SettingsWindow : Window
    {
        
        private SettingsWindow()
        {
            InitializeComponent();
        }

        
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

      
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }
    }
}
