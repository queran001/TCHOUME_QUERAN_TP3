﻿using System;
using System.Collections.Generic;
using WeatherWidget.Helpers;
using WeatherWidget.Helpers.JSON;

namespace WeatherWidget.Converters
{
    public static class JsonConverter
    {
        public static OpenWeatherResponce? ToOpenWeatherResponce(JSONResponce jsonResponce)
        {
            if (jsonResponce == null) return null;

            try
            {
                
                List<OpenWeatherDay> days = new List<OpenWeatherDay>();
                
                List<OpenWeatherState> weatherStates = new List<OpenWeatherState>();
                
                int lastItemDay = DateTime.Parse(jsonResponce.Items[0].DateTime).Day;
                
                int currentItemDay;

                
                foreach (var item in jsonResponce.Items)
                {
                    currentItemDay = DateTime.Parse(item.DateTime).Day;

                    if (lastItemDay == currentItemDay)
                    {
                        weatherStates.Add(ToWeatherState(item));
                    }
                    else
                    {
                        
                        days.Add(new OpenWeatherDay(weatherStates));
                        weatherStates = new List<OpenWeatherState>();
                        
                        weatherStates.Add(ToWeatherState(item));
                        lastItemDay = currentItemDay;
                    }
                }

                return new OpenWeatherResponce(days, jsonResponce.City);
            }
            catch (Exception)
            {
                return null;
            }
        }

        
        public static OpenWeatherState ToWeatherState(JSONListItem item)
        {
            return new OpenWeatherState
            (
                minTemperature: item.MainInfo.Temp_min,
                maxTemperature: item.MainInfo.Temp_max,
                description: item.WeatherTypes[0].Description,
                dateTime: DateTime.Parse(item.DateTime)
            );
        }
    }
}
