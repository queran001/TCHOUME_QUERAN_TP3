﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace WeatherWidget.Helpers.JSON
{
    
    public class JSONResponce
    {
        
        [JsonProperty("list")]
        internal List<JSONListItem> Items { get; set; }

       
        [JsonProperty("city")]
        internal JSONCity City { get; set; }
    }

    
    public class JSONListItem
    {
        [JsonProperty("main")]
        public JSONMainInfo MainInfo { get; set; }

        
        [JsonProperty("weather")]
        public List<JSONWeatherType> WeatherTypes { get; set; }

        
        [JsonProperty("dt_txt")]
        public string DateTime { get; set; }
    }

    
    public class JSONMainInfo
    {
        
        [JsonProperty("temp_min")]
        public double Temp_min { get; set; }

        
        [JsonProperty("temp_max")]
        public double Temp_max { get; set; }
    }

   
    public class JSONWeatherType
    {
       
        [JsonProperty("description")]
        public string Description { get; set; }
    }

   
    public class JSONCity
    {
        
        [JsonProperty("name")]
        public string Name { get; set; }

        
        [JsonProperty("country")]
        public string Country { get; set; }
    }
}