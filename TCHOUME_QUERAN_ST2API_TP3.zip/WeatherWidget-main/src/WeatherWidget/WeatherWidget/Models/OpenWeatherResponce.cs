﻿using System.Collections.Generic;
using WeatherWidget.Helpers.JSON;

namespace WeatherWidget.Helpers
{
    
    public partial class OpenWeatherResponce
    {
        
        private readonly List<OpenWeatherDay> _days;

        public IReadOnlyList<OpenWeatherDay> Days => _days.AsReadOnly();

        
        public JSONCity City { get; private set; }

        
        public OpenWeatherResponce(List<OpenWeatherDay> days, JSONCity city)
        {
            _days = days;
            City = city;
        }
    }
}
