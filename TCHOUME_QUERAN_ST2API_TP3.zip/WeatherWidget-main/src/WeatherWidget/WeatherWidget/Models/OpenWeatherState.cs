﻿using System;

namespace WeatherWidget.Helpers
{
    
    public partial class OpenWeatherState
    {
        
        public double MinTemperature { get; set; }

        
        public double MaxTemperature { get; set; }

       
        public string Description { get; set; }

        
        public DateTime DateTime { get; set; }

        
        public OpenWeatherState(double minTemperature, double maxTemperature, string description, DateTime dateTime)
        {
            MinTemperature = minTemperature;
            MaxTemperature = maxTemperature;
            Description = description;
            DateTime = dateTime;
        }
    }
}
