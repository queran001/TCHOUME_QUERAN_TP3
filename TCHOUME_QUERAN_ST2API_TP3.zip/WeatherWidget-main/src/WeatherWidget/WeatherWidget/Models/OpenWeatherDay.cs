﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WeatherWidget.Helpers
{
    
    public class OpenWeatherDay
    {
       
        public List<OpenWeatherState> WeatherStates { get; private set; }

        
        public OpenWeatherDay(List<OpenWeatherState> weatherStates)
        {
            WeatherStates = weatherStates;
        }

        
        public double GetAVGTemp()
        {
            return (GetMinTemperature() + GetMaxTemperature()) / 2;
        }

       
        public double GetMinTemperature(bool round = true)
        {
            double result = WeatherStates[0].MinTemperature;

            foreach (OpenWeatherState weather in WeatherStates)
            {
                if (result > weather.MinTemperature)
                {
                    result = weather.MinTemperature;
                }
            }

            return round ? Math.Round(result) : result;
        }

        
        public double GetMaxTemperature(bool round = true)
        {
            double result = WeatherStates[0].MinTemperature;

            foreach (OpenWeatherState weather in WeatherStates)
            {
                if (result < weather.MinTemperature)
                {
                    result = weather.MinTemperature;
                }
            }

            return round ? Math.Round(result) : result;
        }

       
        public DateTime GetDate()
        {
            return new DateTime(WeatherStates[0].DateTime.Year, WeatherStates[0].DateTime.Month, WeatherStates[0].DateTime.Day);
        }

        
        public string GetUniqueDescriptions()
        {
            
            var uniqueDescription = WeatherStates.OrderByDescending(i => i.Description).DistinctBy(j => j.Description).ToList();
            string result = string.Empty;

            if (uniqueDescription.Count > 0)
            {
                for (int i = 0; i < uniqueDescription.Count - 1; i++)
                {
                    result += $"{uniqueDescription[i]}, ";
                }
                result += uniqueDescription[uniqueDescription.Count - 1];
            }

            return result;
        }

        
        public string GetFrequentDescription()
        {
            var uniqueWeatherStatess = WeatherStates.OrderByDescending(i => i.Description).DistinctBy(j => j.Description).ToList();

            if (uniqueWeatherStatess.Count > 0)
            {
                return $"{uniqueWeatherStatess[0].Description}";
            }
            else return "no weather data";
        }
    }
}
